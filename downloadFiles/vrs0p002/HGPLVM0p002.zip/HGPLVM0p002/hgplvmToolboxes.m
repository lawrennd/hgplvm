
% HGPLVMTOOLBOXES Load in the relevant toolboxes for hgplvm.
%
%	Description:
%	

%	Copyright (c) 2006 Neil D. Lawrence
% 	hgplvmToolboxes.m version 1.3

importLatest('fgplvm');
importLatest('gp');
importLatest('netlab');
importLatest('mocap');
importLatest('ndlutil');
importLatest('prior');
importLatest('mltools');
importLatest('optimi');
importLatest('datasets');
importLatest('kern');
