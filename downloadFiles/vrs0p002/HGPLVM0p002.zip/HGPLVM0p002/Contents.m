% HGPLVM toolbox
% Version 0.002		Wednesday 29 Nov 2006 at 12:01
% Copyright (c) 2006 Neil D. Lawrence
% 
% ACCLAIM2XYZHIERARCHICAL Compute XYZ values given skeleton structure and channels.
% DEMRUN1 Show visualisation of the run.
% DEMSUBSKELS Load in the walk1 skeleton and motion capture, then break up into sub skels and learn models on each sub skel.
% DEMSUBSKELS2 Load in the walk1 skeleton and motion capture, then break up into sub skels and learn models on each sub skel.
% DEMSUBSKELSH Run a given data set in the hierarchical GP-LVM.
% DEMWALK1 Show visualisation of the walk.
% FGPLVMHIERARCHICALVISUALISE Visualise the manifold.
% GETMAXTREEDIMENSIONS 
% HIERARCHICALLATENTSPACEHANDLER Event handler for the HGPLVM latent space.
% HIERARCHICALMODELLEARNER Learns models for the supplied skeletal hierarchy.
% LVMHIERARCHICALSCATTERPLOT 2-D scatter plot of the latent points.
% PLOTSUBSKEL Plot a given subskeleton.
% SKELGETSUBSKEL Gets a sub-skeleton from a larger skeleton.
% SKELMODIFYHIERARCHICAL Helper code for visualisation of skel data.
% SKELVISUALISEHIERARCHICAL For updating a skel representation of 3-D data.
% TESTFUNC Handler for mouse events on the latetn space axes.
