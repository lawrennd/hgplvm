function visHandle = plotSubskel(visIndex, model, skel, padding)

% PLOTSUBSKEL Plot a given subskeleton.
%
%	Description:
%
%	PLOTSUBSKEL(VISINDEX, MODEL, SKEL, PADDING) plots a sub skeleton on
%	for the given visualisation.
%	 Arguments:
%	  VISINDEX - the index of the visualisation structure into which the
%	   plot will be made.
%	  MODEL - the model containing the learned information about the
%	   skeleton to be plotted.
%	  SKEL - the skeleton structure to be plotted.
%	  PADDING - any padding to be added to the skeleton.
%	


%	Copyright (c) 2006 % COPYRIGHT Andrew Moore
% 	plotSubskel.m version 1.3

global visualiseInfo;
figure(2)

visData = zeros(1, model.d);
%set visData to frame with max sum of squares of joint angles
[void, maxInd] = max(sum((model.y.*model.y), 2));
visData = model.y(maxInd, :);

visHandle = visualiseInfo(visIndex).visualiseFunction(visData, skel, visIndex, padding);

set(visHandle, 'eraseMode', 'xor');
colormap gray;




