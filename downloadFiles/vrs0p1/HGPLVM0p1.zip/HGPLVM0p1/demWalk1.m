
% DEMWALK1 Show visualisation of the walk.
%
%	Description:
%	

%	Copyright (c) 2007 Neil D. Lawrence
% 	demWalk1.m version 1.1


load data_35_04_walk.mat
load data_35_dependencies.mat
colordef white
fgplvmHierarchicalVisualise(visualiseNodesData, dependencies);