% HGPLVM toolbox
% Version 0.001		Thursday 09 Nov 2006 at 15:10
% Copyright (c) 2006 Neil D. Lawrence
% 
% GETMAXTREEDIMENSIONS 
% LVMHIERARCHICALSCATTERPLOT 2-D scatter plot of the latent points.
% DEMSUBSKELS2 Load in the walk1 skeleton and motion capture, then break up into sub skels and learn models on each sub skel.
% DEMSUBSKELSH Run a given data set in the hierarchical GP-LVM.
% FGPLVMHIERARCHICALVISUALISE Visualise the manifold.
% HIERARCHICALMODELLEARNER Learns models for the supplied skeletal hierarchy.
% DEMSUBSKELS Load in the walk1 skeleton and motion capture, then break up into sub skels and learn models on each sub skel.
% PLOTSUBSKEL Plot a given subskeleton.
% TESTFUNC Handler for mouse events on the latetn space axes.
% HIERARCHICALLATENTSPACEHANDLER Event handler for the HGPLVM latent space.
